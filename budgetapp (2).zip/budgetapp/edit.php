<?php
$servername = "localhost";
$databasename="budgetapp";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $databasename);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
?>
<?php

if(isset($_GET['id'])) {
  $selectedid=$_GET['id'];
}

elseif (isset($_POST['btn_update'])) {
  $id= $_POST['id'];
  $itemname= $_POST['itemname'];
  $itemcost= $_POST['itemcost'];
  $query="UPDATE tbl_budgetitem SET itemname='{$itemname}', itemcost='{$itemcost}' 
  WHERE id=$id";
  $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
  header("Location: edit.php");
}

else{
  header("Location: index.php");
}
  //fetch
  $query="SELECT * FROM tbl_budgetitem WHERE id=$selectedid";
  $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
  while ($row=mysqli_fetch_array($result)) {
      $itemname=$row['itemname'];
      $itemcost=$row['itemcost'];
    }

?>


<!DOCTYPE html>
<html>
<head>
  <title></title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <style >
  	body{
  		 background-image: url(../images/bag2.jpg);
  		  background-attachment: ;
    background-size: cover;
    min-height: 800px;
    background-position: center;

  	}
  </style>

</head>
<body>
  <div class="container-fluid">
    <div class="row">
    <div class="col-md-2"></div>
      <div class="col-md-8" id="index">
      <h2 style="font-size:25px;text-align: center;margin-top: 30px;font-family: roboto;margin-bottom: 10px;">The Decision is in Your Hands</h2>

  <!-- form2 start -->
  <form class="" method="POST" action="edit.php">
     
    <input type="hidden" name="id" value="<?php echo $selectedid; ?>">
   <label><h2 style="margin-top: 50px;font-size: 18px">Itemname:</h2></label>
    <br>
    <input type="text" name="itemname"  value="<?php echo $itemname; ?>" placeholder="Enter item name" class="form-control" >
 
     <label><h2 style="font-size: 18px;">Item cost</h2></label>
     <br>

    <input type="text" name="itemcost" value="<?php echo $itemcost; ?>" placeholder="Enter item cost" class="form-control" >
    <br>
     <label><h2 style="font-size: 18px;">Your Decision</h2></label>
     <br>
    <input type="submit" name="btn_update" value="Update" class="btn btn-danger " style="margin: 0 auto;" class="form-control" >
   <label></label>
    <input type="submit"   name="btn_cancel"  class="btn btn-success" value="Cancel" class="form-control" >
  </form>
  <!-- form2 collapse -->

  </div>

  <div class="col-md-2"></div>
  </div>
</body>
</html>