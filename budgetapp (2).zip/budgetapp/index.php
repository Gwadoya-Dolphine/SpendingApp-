<?php 
        //require connection
        require("includes/connection.php");

        //require session
        require("includes/session.php");

        //call confirm logged in 
        confirm_logged_in();


        $session_email = $_SESSION['email'];

        //fetch 
         $query = "SELECT * FROM budgetapp_tbl WHERE email = '$session_email'";
         $result = mysqli_query($conn, $query)  OR die(mysqli_error($conn));

         while($row = mysqli_fetch_array($result)){
               $session_userid = $row['id'];
               $session_firstname = $row['firstname'];
               $session_lastname = $row['lastname'];

         }
         ?>

<?php
  if (isset($_POST['btn_update'])) {
    $itemname=$_POST['itemname'];
    $itemcost=$_POST['itemcost'];

    $query="INSERT INTO tbl_budgetitem(itemname,itemcost) VALUES('{$itemname}', '{$itemcost}')";

    $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
    header("Location: index.php");
  }
  ?>
  <?php
  if (isset($_POST['btn_update'])) {
    $itemname=$_POST['itemname'];
    $itemcost=$_POST['itemcost'];  
  }
  if (isset($_GET['deleteid'])) {
    $deleteid=$_GET['deleteid'];
    $query="DELETE FROM tbl_budgetitem WHERE id=$deleteid";
    $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
    header("Location: index.php?success_update=true");
  }
  ?>

<!DOCTYPE html>
<html>
<head>
  <title></title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container-fluid" id="most" style="background-color:grey;">
    <div class="col-md-2"> </div>
    <div class="col-md-8">
     <?php

          echo '<h2 style="text-align:center;font-size:20px;font-family:arial;margin-top:90px;">WELCOME '.$session_firstname.' '. $session_lastname.'</h2>';

         echo '<a href="logout.php"><h1 style="text-align:right;font-size:20px;">LOG OUT</h1></a> <br> <br>'
     ?>
    <?php
              if (isset($_GET['success_delete'])) {
                  # code...?>
            <div class="alert alert-success alert-dismissable">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <strong>update Successfully!</strong> 
                    </div>
            <?php } ?>

            <?php
              if (isset($_GET['error_delete'])) {
                  # code...
                  ?>
             <div class="alert alert-danger">
                   <strong>Danger!</strong> Access denied <a href="#" class="alert-link"></a>.
                      </div>
                   </div>
            <?php } ?>
     <h2 style="text-align: center;font-size: 30px;font-family: arial;position: relative;bottom: 40px;color: magenta;">LEARN TO BUDGET</h2>
     <!-- form start -->
       <form method="POST" action="index.php">
         <input type="text" name="itemname" placeholder="Item Name"  class="form-control"><br><br>
         <input type="number" name="itemcost" placeholder="Item Cost"  class="form-control"><br>
         <input type="submit" name="btn_update" value="ADD" class="btn btn-success" style="width: 100%;">
           
       </form>
       <!-- form collapse -->

       <!-- table start -->
         <table class="table">
           <thead>
             <tr>
               <td>Itemname</td>
               <td>Itemcost</td>
               <td>Action</td>
             </tr>
           </thead>
           <?php
           $query= "SELECT * FROM tbl_budgetitem";
           $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
           while ($row=mysqli_fetch_array($result)) {
             echo '<tr>';
               echo '<td>'.$row['itemname'].'</td>';
               echo '<td>'.$row['itemcost'].'</td>';
               echo '<td>
               <a class="btn btn-primary btn-sm" href="edit.php?id='.$row['id'].'">Edit</a> 
               <a class="btn btn-danger btn-sm" href="index.php?deleteid='.$row['id'].'" onclick="return confirm(\'delete\');">Delete</a>
                </td>';
             echo '</tr>';
           }
           ?>
         </table>
         <td>
    
         </td>
         <!-- table collapse -->
         <h3 align="center" style="font-size: 18px;margin-bottom: 30px;color: black;"><a href="login.php">BACK</a></h3>
    
    <div class="col-md-2"> </div>
  </div></div>
</body>
</html>